# -*- coding: utf-8 -*-
"""
This script initializes the plugin, making it known to QGIS.
"""

def classFactory(iface):
    """Load AntiGraffitiPlugin class from file AntiGraffitiPlugin.
    
    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .plugin import AntiGraffitiPlugin
    return AntiGraffitiPlugin(iface)
